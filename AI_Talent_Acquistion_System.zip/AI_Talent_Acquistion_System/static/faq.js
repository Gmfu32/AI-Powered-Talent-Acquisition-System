document.addEventListener('DOMContentLoaded', () => {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    const icon = question.querySelector('.icon');

    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');

      // Collapse all others
      faqItems.forEach(i => {
        i.classList.remove('active');
        const iIcon = i.querySelector('.icon');
        if (iIcon) iIcon.textContent = '+';
      });

      // Toggle current
      if (!isActive) {
        item.classList.add('active');
        icon.textContent = '–';
      } else {
        icon.textContent = '+';
      }
    });
  });
});
